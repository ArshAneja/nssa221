#!/bin/python3

'''
Arsh Aneja
3/12/2022
'''

import os
from datetime import date
import re
from geoip import geolite2
from ip2geotools.databases.noncommercial import DbIpCity




unique = []
os.system('clear')

#Date
today = date.today()
d = today.strftime("%B %d, %Y")
print("Today's date:", d)




#Used to sort by number
def Sort(list):
	return(sorted(list,key = lambda x: x[0]))

#Read file
def read(filename):
	#Calc numbers
	a = 0
	b = 0
	c = 0
	d = 0
	e = 0
	f = 0
	g = 0
	h = 0
	i = 0
	j = 0
	k = 0
	l = 0
	m = 0
	n = 0
	o = 0
	p = 0
	z = 0
	frame = []
	var = []
	print("\n\nCount\t\tIP Address\t\tCountry")
	with open(filename) as file:
		for line in file:
			#Finds all ip address in text using regex
			pattern = re.findall('(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', line)
			#Calc attacks.
			for x in pattern:
				if x == "218.25.208.92":
					a += 1
				if x == "8.19.245.2":
					b += 1
				if x == "183.3.202.111":
					c += 1
				if x == "195.154.49.74":
					d += 1
				if x == "159.122.220.20":
					e += 1
				if x == "182.100.67.59":
					f += 1
				if x == "54.239.25.200":
					g += 1
				if x == "180.128.252.1":
					h += 1
				if x == "41.223.57.47":
					i += 1
				if x == "208.109.54.40":
					j += 1
				if x == "23.248.147.162":
					k += 1
				if x == "40.74.118.11":
					l += 1
				if x == "62.210.189.248":
					m += 1
				if x == "141.212.122.112":
					n += 1
				if x == "199.204.45.176":
					o += 1
				if x == "119.15.137.149":
					p += 1
				#Find all ips that were under attack.
				if x not in unique:
					unique.append(x)
					#Adds count : ip
					frame = [[a,"218.25.208.92"],[b,"8.19.245.2"],[c,"183.3.202.111"],[d,"195.154.49.74"],[f,"182.100.67.59"],
						 [g,"54.239.25.200"],[h,"180.128.252.1"],[i,"41.223.57.47"],[j,"208.109.54.40"],[k,"23.248.147.162"],[l,"40.74.118.11"],
						 [m,"62.210.189.248"],[n,"141.212.122.112"],[o,"199.204.45.176"],[p,"119.15.137.149"],[e,"159.122.220.20"]]
	#Sorted
	var = Sort(frame)
	#Iterate through the nested loop
	for x in var:
		ip = geolite2.lookup(x[1])
		if ip == None:
			continue
		#Get country
		country = ip.country
		#Filter
		if x[0] >= 10:
			#Print output
			print(x[0],"\t\t",x[1],"\t\t",country)

#Main method
def main():
	read("syslog.log")
main()


